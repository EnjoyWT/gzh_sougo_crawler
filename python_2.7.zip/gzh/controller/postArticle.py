#-*- coding: utf8 -*-

import urllib2
from pymongo.mongo_client import MongoClient
from poster.streaminghttp import register_openers
from poster.encode import multipart_encode
import json
import os
from bs4 import BeautifulSoup
import gridfs

class Post_Article(object):
    '''
    向科协CMS后台提交文章数据
    {'channelId': 1,
    'title': '',
    'content': '',
    'source': '',
    'url': '',
    'imgs': []}
    '''
    
    imgs = []
    localImgs = []

    def __init__(self):
        self.host = '127.0.0.1'
        self.port = 27017
        self.client = MongoClient(self.host,self.port)
        self.db = self.client['gzh']
        self.collection = self.db['HSA_Collection']
        
        self.__imgfs =gridfs.GridFS(self.db)


    def getSub_ChannelName(self,classifys):
        if len(classifys)==0:
            return None
        channels=""
        for classify in classifys:
            try:
                if len(classify)>=len(channels):
                    channels=classify
            except:
                continue
        channellist=channels.split(":::")
        if channellist is not None and len(channellist)>0:
            if len(channellist)==2:
                sub_channel=channellist[1]
            elif len(channellist)>=3:
                sub_channel=channellist[2]
            else:
                return None
        return sub_channel

    def cleanTempImages(self):

        rootdir = '/Users/lianzhu/Desktop/122'
        filelist = os.listdir(rootdir)

        for f in filelist:

            filepath = os.path.join(rootdir, f)

            if os.path.isfile(filepath):
                try:
                     os.remove(filepath)
                except:
                    print '删除临时图片时出错,请查看缓存图片路劲下是否有其他文件夹'
                    continue
    def generateParams(self):
        items =  self.collection.find(no_cursor_timeout=True)

        def dealTextTitle(textTitle):
            temtext = textTitle
            if textTitle[0:3].startswith(u"原创"):
                temtext = textTitle[3:]
            return temtext

        for item in items:
            # if item.has_key('is_nanjing_post'):
            #     is_post = item['is_nanjing_post']
            #     if is_post == 1:
            #         continue

            judge = True
            # if item['source']=="" or item['source']==u"来源：":
            #     article_source=item['site_name']
            # else:
            article_source=item['source']
            #tie = dealTextTitle(item['title'])
            params = [('title', item['title']),
                      ('content', item['content']),
                      ('source', article_source)]

            params.append(('channelId', '4660'))

            if item.has_key('imgs'):
                if not item['imgs'] is None and len(item['imgs']) > 0:
                    for imgItem in item['imgs']:
                        try:
                            imgdata = self.getimgdata(imgItem['name'])
                            if imgdata is None:
                                judge = False
                                break
                            imgpath = "/Users/lianzhu/Desktop/122/" + imgItem['name']
                            imgout = open(imgpath, 'wb')
                            imgout.write(imgdata)

                            params.append(('imgs', open(imgpath, 'rb')))
                        except:
                            print 'dfd'
                            judge = False
                            break

            #self.cleanTempImages()
            # print '==========='
            # print item['content']
            # print '==========='
            if judge:
                pass
                self.post(params,item)
            else:
                print 'fail'

    
    def getimgdata(self,filename):
        gf = None
        try:
            gf  = self.__imgfs.get_version(filename)
            im = gf.read()                 #read the data in the GridFS
            return im
        except Exception,e:
            return None
        finally:
            if gf:
                gf.close()

    def post(self,params,item):


        #南京
        url = '45335353'


        result = None
        if url is None or len(url) == 0 or params is None or len(params) == 0:
            return False
        try: 
            register_openers()
            datagen, headers = multipart_encode(params)
            request = urllib2.Request(url, datagen, headers)
            result = urllib2.urlopen(request).read()
            print result
            result = json.loads(result)
        except Exception, e:
            # print 'Reason what: ', e.reason
            result = None
        finally:
            if result is None or len(result) == 0 or 'type' not in result or result['type'] != 'SUCCESS':
                print 'post fail'
            if not result is None and len(result) > 0:
                if result.has_key('type'):
                    if result['type'] == 'SUCCESS':
                        self.collection.update(item,{"$set":{'is_nanjing_post':1}})


if __name__ == '__main__':
    Post_Article().generateParams()
    # s = '0hello good boy doiido'
    # print s[1:]
