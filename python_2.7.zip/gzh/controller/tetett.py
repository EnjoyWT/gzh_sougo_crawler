# -*- coding:utf-8 -*-

s= u"http://mmbiz.qpic.cn/mmbiz_jpg/FMuqBDd2WEst8EVPaKWAyUwPvW6GY8ZlckmKoj2ADDoAsgr5lK2gpiaGomjBBickYmDibpmictLMic3gSDG5KYzCBFg/640?tp=webp&amp;wxfrom=5&amp;wx_lazy=1"

s=s.replace("http://mmbiz.qpic.cn/mmbiz_jpg/FMuqBDd2WEst8EVPaKWAyUwPvW6GY8ZlckmKoj2ADDoAsgr5lK2gpiaGomjBBickYmDibpmictLMic3gSDG5KYzCBFg/640?tp=webp&amp;wxfrom=5&amp;wx_lazy=1",'34')

print s

