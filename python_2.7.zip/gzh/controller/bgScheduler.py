#-*- coding: utf8 -*-
'''
Created on 2016年10月27日

@author: wangyf
'''
from apscheduler.jobstores.mongodb import MongoDBJobStore
from apscheduler.jobstores.memory import MemoryJobStore
from data.db import mongoClient
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.events import EVENT_JOB_EXECUTED, EVENT_JOB_ERROR
from apscheduler.executors.pool import ThreadPoolExecutor, ProcessPoolExecutor
from data.dataConfig import DBNAME_MONGO_JOB ,dbConfig
#from service.task.searchword_post import SearchWord_Post
from controller.manger import Manger
import time
import logging
logging.basicConfig()
class BgScheduler(object):
    '''
    计划任务管理
    '''

    jobstores = {
        'mongo': MongoDBJobStore(collection=DBNAME_MONGO_JOB, 
                                 database=dbConfig['mongo']['name'], 
                                 client=mongoClient),
        'default': MemoryJobStore()
    }
    executors = {
        'default': ThreadPoolExecutor(10),
        'processpool': ProcessPoolExecutor(3)
    }
    job_defaults = {
        'coalesce': True,
        'max_instances': 3
    }
    
    sched = None

    def __init__(self):

        self.sched = BackgroundScheduler(jobstores=self.jobstores, 
                                         executors=self.executors, 
                                         job_defaults=self.job_defaults)

    '''
    计划任务监听
    '''
    def job_listener(self, event):
        if event.exception:

            self.restart()
            
    '''
    执行搜索词发送任务
    '''
    def searchword_post(self):
        #SearchWord_Post().listPost()
        print time.time()


    def gongzhonghao(self):
        Manger().run()
    '''
    启动计划
    '''
    def start(self):
        # self.sched.add_job(self.gongzhonghao,
        #                    'cron',
        #                    hour='0-24',
        #                    minute='0,2,4,8,12,15,18,21,24,27,30,33,36,39,42,45,48,51,54,57',
        #                    second='0',
        #                    id='searchword_post')
        # self.sched.add_listener(self.job_listener,
        #                         EVENT_JOB_EXECUTED | EVENT_JOB_ERROR)

        self.sched.add_job(self.gongzhonghao,'interval',seconds=90)

        self.sched.start()

        return True
    
    '''
    重启任务
    '''
    def restart(self):
        existJobIds = []
        for job in self.sched.get_jobs():
            if existJobIds.count(job.id) == 0:
                existJobIds.append(job.id)
        for jobId in existJobIds:
            self.sched.remove_job(jobId)
        if len(existJobIds) > 0: #这里如果任务未启动可能抛出异常,在本项目中不会
            self.sched.shutdown(wait=False)
        return self.start()

if __name__ == '__main__':


     b= BgScheduler()
     b.gongzhonghao()
    # b.start()
    #
    # try:
    #     # This is here to simulate application activity (which keeps the main thread alive).
    #     while True:
    #         time.sleep(2)
    # except (KeyboardInterrupt, SystemExit):
    #     # Not strictly necessary if daemonic mode is enabled but should be done if possible
    #     b.sched.shutdown()
