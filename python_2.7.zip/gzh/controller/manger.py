# -*- coding:utf-8 -*-

from spiders.gzh_spider import  GZH_Spider
import os,sys
import json
import gc
from  postArticle import Post_Article
class Manger(object):

    def __init__(self):
        pass

    def run(self):
        # 公众号+微信号,多个公众号对应不同的微信号

         #a = time.time()
         g = GZH_Spider()
         items = self.fecthAccount()
         for item in items:

                 valid = item['valid']
                 if valid ==0:
                     continue


                 ofName = item['officialAccountName']
                 wName = item['weChatName']

                 g.crawlOfficialAccount(officialAccountName=ofName, weChatName=wName if len(wName)>0 else None)

         del items
         gc.collect()

         g.closeDrive()

         #Post 文章
         # parse = Post_Article()
         # parse.generateParams()
         #b = time.time()
         # print b-a


    def fecthAccount(self):

        #accounts_File = open('/Users/lianzhu/Desktop/gzh/controller' + '/accountsFile.json', 'r')
        accounts_File = open(self.current_file_dir() + '/accountsFile.json', 'r')
        tempList = []
        try:
            all_the_text = accounts_File.read()
            arr = json.loads(all_the_text)
        finally:
            accounts_File.close()

        for item in arr:
            if item['valid']>0:
                tempList.append(item)

        return tempList

    def current_file_dir(self):

        '''
        判断为脚本文件还是py2exe编译后的文件，如果是脚本文件，则返回的是脚本的目录，如果是py2exe编译后的文件，则返回的是编译后的文件路径
        return:当前脚本路径
        '''
        path = sys.path[0]
        if os.path.isdir(path):
            return path
        elif os.path.isfile(path):
            return os.path.dirname(path)
if __name__ == '__main__':
    m = Manger()
    m.run()


