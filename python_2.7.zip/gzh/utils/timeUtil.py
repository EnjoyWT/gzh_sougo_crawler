#-*- coding: utf8 -*-
'''
Created on 2016年7月12日

@author: wangyf
'''
import time
import datetime

class TimeUtil(object):
    '''
    时间通用类
    '''

    ISOTIMEFORMAT = '%Y-%m-%d %X'

    def __init__(self):
        pass
    
    def currentTime(self):
        return time.strftime(self.ISOTIMEFORMAT, time.localtime(time.time()))
    
    def nDaysAgo(self, days=-15):
        now_time = datetime.datetime.now()
        ago_time = now_time + datetime.timedelta(days=days)
        return ago_time.strftime(self.ISOTIMEFORMAT)
    
    def getTime(self, formatStr, _time=None):
        if _time is None:
            return time.strftime(formatStr, time.localtime())
        return time.strftime(formatStr, time.localtime(_time))
    
    def get_y_m_d(self):
        return time.localtime()[0:3]
    
    def get_y_m(self):
        return time.localtime()[0:2]
        