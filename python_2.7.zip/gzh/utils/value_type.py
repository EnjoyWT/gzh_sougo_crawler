#-*- coding: utf8 -*-
'''
Created on 2017年1月29日

@author: wangyf
'''

class Value_Type(object):
    '''
    值类型
    '''
    
    STR = 1
    INT = 2
    LONG = 3
    
    def __init__(self):
        pass
    
    def valid(self, _type):
        if _type == self.STR \
            or _type == self.INT \
            or _type == self.LONG:
            return True
        return False
        