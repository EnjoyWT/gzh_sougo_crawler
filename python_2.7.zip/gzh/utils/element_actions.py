#-*- coding: utf8 -*-
'''
Created on 2017年1月31日

@author: wangyf
'''

from selenium.webdriver.support.wait import WebDriverWait
from selenium.common.exceptions import TimeoutException
from utils.value_type import Value_Type
from  random import randint
import  time


class Element_Actions(object):
    '''
    页面元素行为
    '''

    def __init__(self):
        pass

    '''
    访问一个链接
    '''

    def visitUrl(self, url, _driver, maxTimes=10):
        if not url or len(url) == 0 \
                or not _driver:
            return False
        tryTimes = 0
        # 循环等待加载成功
        while tryTimes < maxTimes:
            try:
                _driver.get(url)
                return True
            except:
                tryTimes += 1
                time.sleep(randint(1, 2))
                continue
        return False

    '''
    在新窗口中访问链接
    '''

    def visitUrl_inNewTab(self, url, _driver):
        if not url or len(url) == 0 \
                or not _driver:
            return False
        js_code = 'window.open("%s");' % (url)
        _driver.execute_script(js_code)
        handles = _driver.window_handles
        # 切换到新窗口
        for handle in handles:
            if handle != _driver.current_window_handle:
                print 'switch to ', handle
                _driver.switch_to_window(handle)
                break
        return True

    '''
    获取cookie
    '''

    def getCookie(self, _driver):
        cookie = [item["name"] + "=" + item["value"] for item in _driver.get_cookies()]
        cookiestr = ';'.join(item for item in cookie)
        return cookiestr

    '''
    翻页
    '''

    def turnPage(self, _driver=None, data_container=None, css_selector_activeA=None, timeOut=5):
        if not _driver or not data_container or not css_selector_activeA:
            return False
        # 等待加载分页栏,如果没有分页栏就跳出循环
        pagination = self.wait_element_css('ul.pagination', data_container, isVisable=True, timeOut=timeOut)
        if not pagination:
            print 'no pagination'
            return False
        # 获取下一页翻页链接,如果没有下一页就跳出循环
        next_a = self.wait_element_link_text('>', pagination, isVisable=True, timeOut=timeOut)
        if not self.element_valid_aNextPage(next_a):
            print 'next_a not valid'
            return False
        # 获取当前页码,如果没有当前页码则跳出循环
        active_a = self.wait_element_css('li.active a', pagination, isVisable=True, timeOut=timeOut)
        # 保存页码
        currentPageText = self.element_text(active_a)
        if not currentPageText:
            print 'cannot get currentPageText'
            return False
        currentPageText = currentPageText.strip()
        # 进入下一页
        self.show_elements(_driver, next_a)
        if not self.element_click(next_a):
            print 'nextPageLink click fail'
            return False
        # 等待翻页成功
        if not self.wait_nextPage_loadFinished(currentPageText, css_selector_activeA, _driver):
            print 'turn page fail'
            return False
        return True

    '''
    点击下一页链接后,等待下一页加载成功
    '''

    def wait_nextPage_loadFinished(self, currentPageText, css_selector_activeA, _driver, maxTimes=30):
        tryTimes = 0
        # 循环等待翻页成功
        while tryTimes < maxTimes:
            # 获取当前页码,如果没有当前页码则跳出循环,如果有，则与currentPageText比较，如果相同，则继续循环等待，如果不同，则跳出循环翻页成功
            active_a = self.wait_element_css(css_selector_activeA, _driver, isVisable=True, timeOut=2)
            pageText = self.element_text(active_a)
            print 'wait_nextPage_loadFinished', currentPageText, pageText
            if not pageText or pageText == currentPageText:
                tryTimes += 1
                time.sleep(randint(1, 2))
                continue
            return True
        return False

    '''
    判断下一页链接是否合法
    '''

    def element_valid_aNextPage(self, elementObj, maxTimes=30):
        if not elementObj:
            return False
        tryIndex = 0
        while True:
            try:
                _tag_name = elementObj.tag_name
                _id = elementObj.get_attribute('id')
                if _tag_name != 'a' or _id != 'ajaxpage':
                    return False
                return True
            except:
                if tryIndex < maxTimes:
                    tryIndex += 1
                    time.sleep(randint(1, 2))
                    continue
                break
        return False

    '''
    获取元素内部属性值
    '''

    def element_attribute(self, elementObj, attributeName, maxTimes=30):
        if not elementObj \
                or not attributeName or len(attributeName) == 0:
            return None
        tryIndex = 0
        while True:
            try:
                return elementObj.get_attribute(attributeName)
            except:
                if tryIndex < maxTimes:
                    tryIndex += 1
                    time.sleep(randint(1, 2))
                    continue
                break
        return None

    '''
    获取元素内部文字
    '''

    def element_text(self, elementObj, maxTimes=30):
        if not elementObj:
            return None
        tryIndex = 0
        while True:
            try:
                return elementObj.text
            except:
                if tryIndex < maxTimes:
                    tryIndex += 1
                    time.sleep(randint(1, 2))
                    continue
                break
        return None

    '''
    页面元素点击
    '''

    def element_click(self, elementObj, maxTimes=30):
        if not elementObj:
            return False
        tryIndex = 0
        while True:
            try:
                elementObj.click()
                return True
            except:
                if tryIndex < maxTimes:
                    tryIndex += 1
                    time.sleep(randint(1, 2))
                    continue
                break
        return False

    '''
    页面元素设置值
    '''

    def element_sendkeys(self, elementObj, val, maxTimes=30):
        if not elementObj:
            return False
        tryIndex = 0
        while True:
            try:
                elementObj.send_keys(val)
                return True
            except Exception, e:
                print Exception
                print e
                if tryIndex < maxTimes:
                    tryIndex += 1
                    time.sleep(randint(1, 2))
                    continue
                break
        return False

    '''
    通过包含内容获取单个页面元素
    '''

    def wait_element_link_text(self, val, elementObj, isVisable=None, timeOut=20):
        try:
            if isVisable is None or isVisable is False:
                return WebDriverWait(elementObj, timeOut).until(lambda x: x.find_element_by_link_text(val))
            elif isVisable is True:
                WebDriverWait(elementObj, timeOut).until(lambda x: x.find_element_by_link_text(val).is_displayed())
                return elementObj.find_element_by_link_text(val)
        except:
            print 'element %s not found' % val
            return None

    '''
    通过css选择器获取单个页面元素
    '''

    def wait_element_css(self, val, elementObj, isVisable=None, timeOut=20):
        try:
            if isVisable is None or isVisable is False:
                return WebDriverWait(elementObj, timeOut).until(lambda x: x.find_element_by_css_selector(val))
            elif isVisable is True:
                WebDriverWait(elementObj, timeOut).until(lambda x: x.find_element_by_css_selector(val).is_displayed())
                return elementObj.find_element_by_css_selector(val)
        except:
            print 'element %s not found' % val
            return None

    '''
    通过css选择器获取多个页面元素
    '''

    def wait_elements_css(self, val, elementObj, timeOut=20):
        try:
            return WebDriverWait(elementObj, timeOut).until(lambda x: x.find_elements_by_css_selector(val))
        except:
            print 'element %s not found' % val
            return None

    '''
    获取页面元素属性值
    valueType: string=1 int=2 float/double=3
    '''

    def get_attribute(self, elementObj=None, attributeName=None, valueType=Value_Type.STR):
        if elementObj is None \
                or attributeName is None or len(attributeName) == 0 \
                or not Value_Type().valid(valueType):
            return None
        try:
            attributeValue = elementObj.get_attribute(attributeName)
            if valueType == Value_Type.STR:
                return attributeValue
            elif valueType == Value_Type.INT:
                return int(attributeValue)
            elif valueType == Value_Type.LONG:
                return long(attributeValue)
            return None
        except:
            return None

    '''
    使元素可见
    '''

    def show_elements(self, _driver, _element):
        if not _driver or not _element:
            return False
        _driver.execute_script("arguments[0].scrollIntoView();", _element)
        return True

    '''
    获取指定ID的页面元素的html代码
    '''

    def outHtml_id(self, _driver, _val, _inner=True):
        if not _driver or not _val:
            return ''
        scriptCodeLines = []
        scriptCodeLines.append('var obj = document.getElementById("%s");' % (_val))
        scriptCodeLines.append('if (obj == null) {return "";}')
        if _inner:
            scriptCodeLines.append('return obj.innerHTML;')
        else:
            scriptCodeLines.append('return obj.outerHTML;')
        return _driver.execute_script(''.join(scriptCodeLines))

    '''
    获取指定ID的页面元素的html代码
    '''

    def outHtml_class(self, _driver, _val, _inner=True, _index=0):
        if not _driver or not _val:
            return ''
        scriptCodeLines = []
        scriptCodeLines.append('var list = document.getElementsByClassName("%s");' % (_val))
        scriptCodeLines.append('if (list == null || list.length == 0) {return "";}')
        if _inner:
            scriptCodeLines.append('return list[%d].innerHTML;' % (_index))
        else:
            scriptCodeLines.append('return list[%d].outerHTML;' % (_index))
        return _driver.execute_script(''.join(scriptCodeLines))

    '''
    获取指定tag的页面元素的html代码
    '''

    def outHtml_tag(self, _driver, _val, _inner=True, _index=0):
        if not _driver or not _val:
            return ''
        scriptCodeLines = []
        scriptCodeLines.append('var list = document.getElementsByTagName("%s");' % (_val))
        scriptCodeLines.append('if (list == null || list.length == 0) {return "";}')
        if _inner:
            scriptCodeLines.append('return list[%d].innerHTML;' % (_index))
        else:
            scriptCodeLines.append('return list[%d].outerHTML;' % (_index))
        return _driver.execute_script(''.join(scriptCodeLines))

    def element_click_webloadtimeIsSeted(self, elementObj, maxTimes=10, web_wait_time_isSetted=False):
        if not elementObj:
            return False
        tryIndex = 0
        while True:
            try:
                elementObj.click()
                return True
            except Exception, e:
                # 只有时间超时的异常才会,直接返回
                if isinstance(e, TimeoutException) and web_wait_time_isSetted == True:
                    return True

                if tryIndex < maxTimes:
                    tryIndex += 1
                    time.sleep(randint(1, 2))
                    continue
                break

        return False
