# -*- coding:utf-8 -*-

import requests
import string
class Downloader(object):

    '''
     TODO:
        1.单例类可以生成统一基类进行继承
        2.图片下载的urls数量达到一定数量是开启多线程(线程获取放在图片处理逻辑的外边,这样模块思路会更清晰一点)
        3.视频下载的逻辑处理,目前仅仅测试过图片,视频暂未测试
    '''
    '''
     本类为单例类,用来下载图片/视频等资源,自动截取下载路径中资源名为保存文件名
    '''

    #_instance = None
    # def __new__(cls, *args, **kw):
    #     if not cls._instance:
    #         cls._instance = super(Downloader, cls).__new__(cls, *args, **kw)
    #     return cls._instance
    def __init__(self):
        pass
    def dowload(self, urls, filePath = None):
        '''
        下载图片/视频,可以接受urlstr,和list
        :param imagesUrl:
        :return: 下载完成后,图片/视频存放的路径数组,反之返回空数组
        '''
        paths = []
        path = ''
        if filePath is not None:

            if filePath.endswith('/'):
                pass
            else:
                path = filePath + '/'

        if isinstance(urls, list):

            for url in urls:

                path = path  + self._sourceName(url,filePath = filePath)

                if self._downloadSource(url=url,filePath=path):
                    paths.append(path)

        elif isinstance(urls, str):

            path = path  + self._sourceName(urls, filePath=filePath)

            if self._downloadSource(url=urls, filePath=path):
                paths.append(path)

        return paths

    def getImageData(self,url = None,tryDownloadtimes = 3):
        '''
        返回url 对应的image 的data/ 使用时调用data.content
        :param url:
        :return: requests.Response
        '''
        currentTimes = 0
        if url is None or len(url)<=0:
            return  None
        while currentTimes < tryDownloadtimes:
            try:
              return  requests.get(url)
            except Exception, e:
                print url
                print '下载资源时网络出现问题'
                print e
                print Exception
                currentTimes += 1
                continue

    def _sourceName(self, url, filePath=None):
        '''
        这里截取下载路径中资源名为存储名,截取不到,返回空字符串.
        :param url:
        :param filePath:
        :return:
        '''
        li = url.split('/')
        if li is not None and len(li) > 0:
            return li[-1]
        else:
            return ''



    def _downloadSource(self, url, filePath, tryDownloadtimes = 3):
        '''
        下载出错时会尝试多次下载(默认三次),下载成功返回True,反之False.
        :param url:
        :param filePath:
        :param tryDownloadtimes:
        :return:
        '''

        if len(url)<=0:
            return False

        currentTimes = 0

        data = self.getImageData(url=url, tryDownloadtimes=3)

       # data = requests.get(url, timeout=10)
        while currentTimes < tryDownloadtimes:
            try:
                with open(filePath, 'wb') as fp:
                    fp.write(data.content)
                return True
            except Exception, e:
                print str(url) + '\n' + '资源存储时出现问题'
                print e
                print Exception
                currentTimes +=1
                continue



        return False

if __name__ == '__main__':

    a  = Downloader()
    a.dowload(['http://pigimg.zhongso.com/space/gallery214/%E5%86%9C%E4%B8%9A%E6%8A%80%E6%9C%AF/previews-med/2139751-茴香软腐病发病症状.jpg',],'/Users/lianzhu/Desktop/122')

