# -*- coding:utf-8 -*-

from  HTMLParser import HTMLParser
# from  re import  sub
# from  sys import stderr
# import  string
import sys

defaultencoding = 'utf-8'

if sys.getdefaultencoding() != defaultencoding:
    reload(sys)
    sys.setdefaultencoding(defaultencoding)

class TransformHtmlToTxt(HTMLParser):
    __singleton = None
    def __init__(self):
        HTMLParser.__init__(self)
        self.__text = []
        self.imgList = []

    def handle_data(self, data):
        text = data
        if len(text) > 10 and \
            not text.startswith('(') and \
            not text.endswith(')') or \
            text[0:20].find('图片来源')==-1 or \
            text[0:20].find('来源')==-1:
                self.__text.append(text)


    def handle_starttag(self, tag, attrs):

        if tag == 'img':
            for(variable, value) in attrs:
                if str(variable)=='src':
                    self.imgList.append(value)
                    break
        elif tag == 'br':
            self.__text.append('\n')
        elif tag =='span':
            pass

    def handle_endtag(self,tag):
       # print tag + 'end'
       # self.__text.append('\n')
        pass

    def text(self):
        #return ''.join(self.__text)
        return  '\n'.join(self.__text) + '\n'
    @staticmethod
    def dehtml(text):
            try:
                if TransformHtmlToTxt.__singleton is None:
                    TransformHtmlToTxt.__singleton = TransformHtmlToTxt()

                TransformHtmlToTxt.__singleton.__text = []
                TransformHtmlToTxt.__singleton.imgList = []
                TransformHtmlToTxt.__singleton.feed(text)
                TransformHtmlToTxt.__singleton.close()
                return (TransformHtmlToTxt.__singleton.text(),TransformHtmlToTxt.__singleton.imgList)
            except Exception, e :
                print  str(Exception)
                print str(e)
                return (text,[])


# def main():
#     text = r'''''
#
#                 <body>
#                     <b>Project:</b> DeHTML<br>
#                     <b>Description</b>:<br>
#                     This small script is intended to allow conversion from HTML markup to
#                     plain text.
#                     <p img-box="img-box"> i am  img-box</p>
#                     <p></p>
#                     <span>i am span </span>
#                 </body>
#
#         '''
#     #dehtml(text)
#     print(TransformHtmlToTxt.dehtml(text))


if __name__ == '__main__':
    main()