# -*- coding:utf-8 -*-
'''
数据库配置 192.168.1.138 ,
'''
#本地测试配置
dbConfig = {'mongo': {'host': '127.0.0.1',
                      'port': 27017,
                      'name': 'gzh'}}


#生产配置
# dbConfig = {'mongo': {'host': '192.168.1.138',
#                       'port': 27017,
#                       'name': 'gzh_chrome'}}

#分页查询时每页默认数量
PAGESIZE = 10
#定时任务表名

DBNAME_MONGO_JOB = 'DBNAME_MONGO_JOB'