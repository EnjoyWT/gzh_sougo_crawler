# -*- coding:utf-8 -*-

from data.db.basetable import BaseTable
from pymongo import ASCENDING
class HSA_Queue_Fail(BaseTable):



    identifyColumns = ['_id',]

    def __init__(self, collectionName=None):

        if collectionName is None:
            print  'collectionName 不可以为空'
            return
        super(HSA_Queue_Fail, self).__init__(collectionName)
        lst = [(column, ASCENDING) for column in self.identifyColumns]
        self.col.ensure_index(lst, unique=True)