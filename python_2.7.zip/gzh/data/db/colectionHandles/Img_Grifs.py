# -*- coding:utf-8 -*-
import gridfs
from utils.downloader import  Downloader
from data.db import mongoDB


class IMG_Grifs(object):
    def __init__(self):
        self._gfs = gridfs.GridFS(mongoDB)


    def img_savein(self,url= None, filename = None):
        if url is None or filename is None or \
                        len(filename)<=0 or len(url)<=0:
            return False

        #存前检测本地是否已存在,不存储任何两张相同名字的图片,图片来取自文章的图片的截取名如:
        #'http://pigimg.zhongso.com/space/gallery/infoimgs/ny/nyjs01/20121114/2012111417225862770.jpg'
        #filename = 2012111417225862770.jpg ,
        exist =self._gfs.exists(filename = filename)
        if exist :
            return True

        data = Downloader().getImageData(url=url)
        try:
         self._gfs.put(data = data.content,filename = filename)
         return True
        except:
            return  False
