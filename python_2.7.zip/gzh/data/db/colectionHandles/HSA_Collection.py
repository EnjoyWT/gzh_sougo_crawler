#-*- coding: utf8 -*-
from data.db.basetable import BaseTable
from pymongo import ASCENDING
class HSA_Collection(BaseTable):


    itemModle = {
        "title": '',
        "abstract": '',
        "author": '',  # 可以为空（空字符串）
        "publishTime": '',
        "source": '',
        "content": '',
        "url": '',
        "thumbnail": '',
        "origin": '',  # 文章来源
        "imgs": [],
        "classify": [],  # ["技术分类:::蔬菜类:::萝卜",""实用技术:::种植技术"]
        "site_url": '',  # 网站首页
        "site_name": '',  # 网站名称
        "processTime": '',
        "praise_cnt": 0,
        "repeat_cnt": 0,
        "forward_cnt": 0,

    }
    identifyColumns = ['_id','identifiers']

    def __init__(self, collectionName=None):

        if collectionName is None:
            print 'collectionName 不可以为空'
            return
        super(HSA_Collection, self).__init__(collectionName)
        lst = [(column, ASCENDING) for column in self.identifyColumns]
        self.col.ensure_index(lst, unique=True)


