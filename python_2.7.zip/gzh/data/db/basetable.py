#-*- coding: utf8 -*-
'''
Created on 2016年6月7日

@author: wangyf
'''
import copy
from data.db import mongoDB
from data.dataConfig import PAGESIZE

class BaseTable(object):
    '''
    所有数据库表的父类
    '''
    identifyColumns = ['_id']
    
    def __init__(self, collectionName):
        self.col = mongoDB[collectionName]
    
    '''
    获取不包含_id的数据库记录
    '''
    def getItem(self, item):
        if item is None:
            return None
        e = copy.deepcopy(item)
        if '_id' in e:
            e.pop('_id')
        return e
    
    '''
    为数据更新获取实际更新的部分，去掉_id和唯一字段
    '''
    def getSetter(self, item):
        if item is None:
            return None
        e = copy.deepcopy(item)
        if '_id' in e:
            e.pop('_id')
        for column in self.identifyColumns:
            if column in e:
                e.pop(column)
        return e
    
    '''
    按条件查询一个结果
    '''
    def get_one(self, d=None):
        if d is None:
            return self.col.find_one()
        return self.col.find_one(d)
    
    '''
    按条件查询多个结果
    '''
    def get_all(self, d=None, sortOptions=None):
        sort = []
        if sortOptions is not None and len(sortOptions) > 0:
            for sortOption in sortOptions:
                sort.append((sortOption['key'], sortOption['direction']))
        if d is None:
            if len(sort) > 0:
                return self.col.find().sort(sort)
            else:
                return self.col.find()
        else:
            if len(sort) > 0:
                return self.col.find(d).sort(sort)
            else:
                return self.col.find(d)
    
    '''
    按条件查询数量
    '''
    def count(self, d):
        if d is None:
            return 0
        query = {}
        for column in self.identifyColumns:
            if column in d:
                query[column] = d[column]
        if d is not None and len(d) > 0:
            if column in d:
                query[column] = d[column]
        return self.col.find(query).count()
    
    '''
    向表中插入一条数据
    '''
    def insert(self, d):
        if d is None:
            return
        try:
            self.col.insert(d)
        except:
            print 'DuplicateKeyError'
    
    '''
    按条件更新表中记录
    '''
    def update(self, d):
        if d is None:
            return
        if len(self.getSetter(d)) == 0:
            return
        query = {}
        for column in self.identifyColumns:
            if column in d:
                query[column] = d[column]
        self.col.update(query,
                        {"$set":self.getSetter(d)})
    
    '''
    通用保存一条记录到表中，查询条件按照指定的identifyColumns
    '''
    def save(self, d):
        if d is None or len(d) == 0:
            return
        if self.count(d) == 0:
            self.insert(d)
        else:
            self.update(d)
    
    '''
    普通搜索
    '''
    def query_all(self, queryDict=None, searchKey=None, sortOptions=None, searchstring=None):
        query = {}
        sort = []
        if searchstring is not None and len(searchstring) > 0 and searchKey is not None and len(searchKey) > 0:
            querylst = []
            for key in searchKey:
                querylst.append({key: {'$regex': searchstring}})
            query['$or'] = querylst
        if queryDict is not None and len(queryDict) > 0:
            if len(query) == 0:
                query = copy.deepcopy(queryDict)
            else:
                t = copy.deepcopy(query)
                query = {'$and': [t, queryDict]}
        if sortOptions is not None and len(sortOptions) > 0:
            for sortOption in sortOptions:
                sort.append((sortOption['key'], sortOption['direction']))
        rlst = self.col.find(query).sort(sort)
        return rlst
    
    '''
    分页搜索
    '''
    def query_page(self, queryDict=None, searchKey=None, sortOptions=None, searchstring=None, page=0, pagesize=PAGESIZE):
        '''
         获取的当前页码超出数据库中页数,返回总页数,和空的数组
        :param queryDict:
        :param searchKey:
        :param sortOptions:
        :param searchstring:
        :param page:
        :param pagesize:
        :return:(pagecnt,[list])  pagecnt:总页数,当前页对象数组
        '''
        query = {}
        sort = []
        if searchstring is not None and len(searchstring) > 0 and searchKey is not None and len(searchKey) > 0:
            querylst = []
            for key in searchKey:
                querylst.append({key: {'$regex': searchstring}})
            query['$or'] = querylst
        if queryDict is not None and len(queryDict) > 0:
            if len(query) == 0:
                query = copy.deepcopy(queryDict)
            else:
                t = copy.deepcopy(query)
                query = {'$and': [t, queryDict]}
        if sortOptions is not None and len(sortOptions) > 0:
            for sortOption in sortOptions:
                sort.append((sortOption['key'], sortOption['direction']))
        if sort is not None and len(sort)>0:
            rlst = self.col.find(query).sort(sort)
        else:
            rlst = self.col.find(query)
        totalcnt = rlst.count()
        pagecount = totalcnt / pagesize
        if totalcnt % pagesize != 0:
            pagecount += 1
        if page >= pagecount:
            return pagecount, []
        _start = page * pagesize
        result = []
        for item in rlst.skip(_start).limit(pagesize):
            result.append(item)
        return pagecount, result
    
    '''
    删除一个
    '''
    def delete_one(self, d):
        if d is not None and len(d) > 0:
            self.col.delete_one(d)
            
    '''
    删除多个
    '''
    def delete_many(self, d):
        if d is not None and len(d) > 0:
            self.col.delete_many(d)
    
    '''
    表中满足条件的记录数量
    '''
    def count_filter(self, d):
        if d is None or len(d) == 0:
            return 0
        cursor = self.col.find(d)
        cnt = cursor.count()
        cursor.close()
        return cnt
    
    '''
    表中所有记录数量
    '''
    def count_all(self):
        cursor = self.col.find()
        cnt = cursor.count()
        cursor.close()
        return cnt
            