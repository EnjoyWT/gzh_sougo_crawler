# -*- coding:utf-8 -*-
# -*- coding:utf-8 -*-
from data.db.colectionHandles.HSA_Collection import HSA_Collection
from data.db.colectionHandles.HSA_Queue import HSA_Queue
from data.db.colectionHandles.HSA_Queue_Fail import  HSA_Queue_Fail
from utils.timeUtil import TimeUtil
import copy
from data.db.colectionHandles.Img_Grifs import IMG_Grifs
from spiderConfig.config import DATAVALIDTIME
class HSA_Data_Center(object):

    def __init__(self):

        #后续,这个会放入配置管理,动态配置数据库
        self.hsa_data_colletion = HSA_Collection('HSA_Collection')
        self.hsa_queue = HSA_Queue('HSA_Queue')
        self.hsa_queue_fail = HSA_Queue_Fail('HSA_Queue_Fail')

        self.timeUtil = TimeUtil()
    '''
        任务入队列
        '''

    def queueIn(self, item=None):
        if item is None or len(item)<2:
            print 'ddd'
            return
        #队列中不重复加入
        tempItem = {'daima':str(item['daima'])}

        if self.hsa_queue.count_filter(tempItem) > 0:
           # print  '队列中已存在'
            return

        #这个时间暂时未设定
        tempItem['crawtime'] = {'$gt': self.timeUtil.nDaysAgo(-15)}
        if self.hsa_data_colletion.count_filter(tempItem) > 0:
           # print  "data is in collention" + " " +item['mingcheng']
            return

        #print item['mingcheng']
        self.hsa_queue.insert(item)

        '''
        任务出队列
        '''

    def queuePop(self, item=None):

        if not item or len(item) == 0:

            return
        # 任务不存在无操作
        if self.hsa_queue.count_filter(item) <= 0:
            print '队列任务不存在'
            return
        self.hsa_queue.delete_one(item)

    def topInQueue(self):

         if self.hsa_queue.count_all() == 0:
             return

         item = self.hsa_queue.get_one()

         tempItem = copy.deepcopy(item)

         self.queuePop(item)

         return tempItem

    def resultIn(self, item=None):

        if item is None :
            print '入库数据为空'
            return



        tempItem = {'identifiers': str(item['identifiers'])}

        tempItem['processTime'] = {'$gt': self.timeUtil.nDaysAgo(-DATAVALIDTIME)}
        if self.hsa_data_colletion.count_filter(tempItem) > 0:
            return

        self.hsa_data_colletion.save(item)

    def resultHaveExist(self,identifier):

        tempItem = {'identifiers': identifier}

        tempItem['processTime'] = {'$gt': self.timeUtil.nDaysAgo(-DATAVALIDTIME)}
        if self.hsa_data_colletion.count_filter(tempItem) > 0:
            return True
        else:
            return False


    def queueIn_fail(self, item=None):

        if item is None:
            return
        self.hsa_queue_fail.save(item)



    def imgSave(self,url = None,name =None):

         return IMG_Grifs().img_savein(url=url,filename=name)