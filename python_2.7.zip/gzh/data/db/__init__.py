# -*- coding:utf-8 -*-
'''
 mongodb初始化
'''
from pymongo.mongo_client import MongoClient
from data.dataConfig import dbConfig

mongoClient = MongoClient(dbConfig['mongo']['host'], dbConfig['mongo']['port'])
mongoDB = mongoClient[dbConfig['mongo']['name']]
