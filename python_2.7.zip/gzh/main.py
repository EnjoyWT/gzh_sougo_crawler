# -*- coding:utf-8 -*-
from  controller.manger import  Manger

if __name__ == '__main__':
    m = Manger()
    m.run()