# -*- coding:utf-8 -*-

#爬虫循环爬取时间,单位: s(秒)
#CRAWLERCYSLETIME = 3600*24*5
CRAWLERCYSLETIME = 10


#数据库数据有效时间,单位:D(天)
DATAVALIDTIME = 15


#定时器任务数据库
