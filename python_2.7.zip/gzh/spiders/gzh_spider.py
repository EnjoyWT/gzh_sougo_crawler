# -*- coding:utf-8 -*-
from utils.element_actions import  Element_Actions
from utils.timeUtil import TimeUtil
from selenium import webdriver
import time
import copy
import hashlib
from  data.db.data_Center.DataCenterManger import  HSA_Data_Center
import gc
from bs4 import BeautifulSoup
import json
import re
class GZH_Spider(object):

    def __driver(self):
        self.driver = webdriver.Chrome(executable_path='/Users/lianzhu/Documents/python/driver/chromedriver')
        #self.driver = webdriver.PhantomJS(executable_path='/Users/lianzhu/Documents/python/driver/phantomjs')
        self.element_actions = Element_Actions()  # 这个以后可以修改成单例,毕竟是个工具而已
        self.baseUrl = 'http://weixin.sogou.com/'
        self.dataCenter = HSA_Data_Center()

    def __init__(self):
        self.__driver()
    def crawlOfficialAccount(self,officialAccountName,weChatName = None):

        articleList=self.begainWithOfficialAccountName(officialAccountName=officialAccountName,
                                                       weChatName = weChatName)
        self.parseArticle(articleUrlList=articleList)
        del articleList
        gc.collect()

    def begainWithOfficialAccountName(self,officialAccountName,weChatName = None):

        if officialAccountName is None or len(officialAccountName)<=0:
            print '公众号名字不可以为空'
            return None
        #self.cleanWendrive()
        success = self.element_actions.visitUrl(url=self.baseUrl, _driver=self.driver)
        if success is False:
            print  '驱动打开网页失败'
            return None

        #找到输入框
        inputElement =  self.element_actions.wait_element_css(elementObj=self.driver,val='input#query')
        if inputElement is None:

            return None

        #print inputElement.get_attribute('outerHTML')

        if not self.element_actions.element_sendkeys(elementObj=inputElement,val=officialAccountName):
            raise('输入框输入字符失败')

       # 找到搜索框
        officialAccountBtn = self.element_actions.wait_element_css(elementObj= self.driver,val='input.swz2')
        if inputElement is None:
            return  None
        if not self.element_actions.element_click(elementObj=officialAccountBtn):
            print '点击按钮失效'
            return


        time.sleep(3)

        # if weChatName is None:
        #     accountUlr= self.fecthFirstAccount()
        # else:
        accountUlr = self.fetchOfficialAccountElement(_driver=self.driver,
                                                          officialAccountName=officialAccountName,weChatName=weChatName)
        if accountUlr is None or len(accountUlr)<=0:
            print '公众号连接为空'
            return None
            # 进入more下一页有无翻页的处理
        old_windowHandler = self.driver.current_window_handle
        if not self.element_actions.visitUrl_inNewTab(accountUlr, self.driver):
            print '新页面打开失败'
            self.driver.switch_to.window(old_windowHandler)
            return None

        articleList = self.element_actions.wait_elements_css(elementObj=self.driver,val='div#history > div')
        #print articleList
        if articleList is None or len(articleList)<=0:
            return None

        articles = []
        dic = {'url': '',
               'name': '',
               'abstract': '',
               'publishTime': '',
               'img': '',
               'source':''
               }


        def dealTextTitle(textTitle):
            temtext = textTitle
            if textTitle[0:3].startswith(u"原创"):
               temtext = textTitle[3:]
            return temtext

        for articleItems in articleList:

            #日期分类文章组
            articleGroupList = self.element_actions.wait_elements_css(elementObj=articleItems,val='div.weui_msg_card_bd > div')
            for item in articleGroupList:

                #单篇文章
                urlE = self.element_actions.wait_element_css(elementObj=item,val='h4.weui_media_title')
                if urlE is None:
                   continue
                urlStr = self.element_actions.get_attribute(urlE,attributeName='hrefs')

                if urlStr is None or len(urlStr)<=0:
                    continue

                tempDic = copy.deepcopy(dic)
                tempDic['url'] = 'http://mp.weixin.qq.com' + urlStr


                tempDic['name'] = dealTextTitle(urlE.text)

                imgE = self.element_actions.wait_element_css(val='.weui_media_hd',elementObj=item)
                imgStr = self.element_actions.get_attribute(elementObj=imgE,attributeName='style')
                imgurl = ''
                if imgStr is not None:
                    imgurl=imgStr.split('(')[1].split(')')[0].replace('"','')
                #获取文章缩略图
                imgName = self.getImgName(urlS=imgurl)
                if self.dataCenter.imgSave(url=imgurl,name=imgName):

                    tempDic['imgUrl'] = imgName
                else:
                    tempDic['imgUrl'] = ''

                #文章名字
                abstractE = self.element_actions.wait_element_css(elementObj=item,val='p.weui_media_desc')
                abstract = ''
                if abstractE is not None:
                    abstract = abstractE.text

                tempDic['abstract'] =abstract
                tempDic['source'] = officialAccountName

                timeE  = self.element_actions.wait_element_css(elementObj= item ,val='p.weui_media_extra_info')
                timeStr = ''

                if timeE is not None:
                    timeStr = timeE.text
                tempDic['publishTime']  = timeStr

                #查询本地是否存在
                temMDList = [tempDic['source'].encode("UTF-8"), tempDic['name'].encode("UTF-8"),
                             tempDic['publishTime'].encode("UTF-8")]

                md5str = self.get_md5_value(temMDList)
                if not self.dataCenter.resultHaveExist(md5str):
                    tempDic['identifiers'] = md5str
                    articles.append(tempDic)
        self.cleanWendrive()
        self.driver.switch_to.window(old_windowHandler)
        return articles


    def cleanWendrive(self):
        self.driver.close()


    def parseArticle(self,articleUrlList):
        resultList = []
        if articleUrlList is None or len(articleUrlList)<= 0:
            print '解析文章列表不可以为空'
            return resultList
        itemModle = {
            "title": '',
            "abstract": '',
            "author": '',  # 可以为空（空字符串）
            "publishTime": '',
            "source": '',
            "content": '',
            "url": '',
            "thumbnail": '',
            "imgs": [],
            "classify": [],  # ["技术分类:::蔬菜类:::萝卜",""实用技术:::种植技术" "]
            "site_url": '',  # 网站首页
            "site_name": '',  # 网站名称
            "processTime": '',
            "praise_cnt": 0,
            "repeat_cnt": 0,
            "forward_cnt": 0,

        }
        for articleUrlDic in  articleUrlList:
            #print articleUrlDic
            self.element_actions.visitUrl(url=articleUrlDic['url'],_driver=self.driver)
            imgs = []
            #文章内容
            contentE = self.element_actions.wait_element_css(val='div#js_content',elementObj=self.driver)

            if contentE is None:
                print '文章内容为空'
                #continue

            contentHtml = self.element_actions.outHtml_id(_driver=self.driver, _val='js_content',_inner=False)
            #contentHtml = contentE.get_attribute('outerHTML')
           # print contentHtml
            #处理图片
            imgsE = self.element_actions.wait_elements_css(val='img',elementObj=contentE,timeOut=13)

            success = True
            try:
                contentHtml = re.sub(u'(\ssrc=".*?")', '', contentHtml)
            except:
                continue

            if imgsE is not None:
                for imgE in imgsE:
                    try:
                        #src 元素
                        tempImgUrlSrc = self.element_actions.get_attribute(elementObj=imgE, attributeName='src')

                        #print re.search(u'(\ssrc=".*?"\s)', contentHtml).groups()

                        #contentHtml = contentHtml.replace(u'src="' + tempImgUrlSrc +u'"','')
                        # print '-----'
                        # print contentHtml
                        # print '------'
                        tempImgUrl = self.element_actions.get_attribute(elementObj=imgE,attributeName='data-src')

                        if tempImgUrl is None:
                            success = False
                            break

                        tempImgName = self.getImgName(tempImgUrl)
                        if tempImgUrl is not None and len(tempImgName) > 0:

                            tempDic = {"name": tempImgName, 'url': tempImgUrl}

                            #contentHtml = contentHtml.replace(tempImgUrl, '/%%path%%/%s' % (tempImgName))
                            contentHtml = contentHtml.replace(u'data-src="'+ tempImgUrl+u'"', u'src="/%%path%%/%s"' % (tempImgName))

                            imgs.append(tempDic)
                        else :
                            print '图片失败3'
                            success = False
                            continue
                    except Exception,e:
                        print Exception
                        print e
                        success = False
                        print '图片失败4'
                        continue


            if success is False:
                print '13434'
                continue
            #图片存入数据库
            for item in imgs:
                if not self.dataCenter.imgSave(url=item['url'],name=item['name']):
                    success = False
                    break



            # 阅读数
            readNumE =self.element_actions.wait_element_css(val='#sg_readNum3',elementObj=self.driver,timeOut=10)
            readNum = 0
            if readNumE is not None:
                readNum = readNumE.text
            likeNumE = self.element_actions.wait_element_css(val='#sg_likeNum3',elementObj=self.driver,timeOut=10)
            likeNum = 0
            if likeNumE is not None:
                likeNum = likeNumE.text
            articleModel = copy.deepcopy(itemModle)
            articleModel['title'] = articleUrlDic['name']
            articleModel['url'] = articleUrlDic['url']
            articleModel['abstract'] = articleUrlDic['abstract']
            articleModel['publishTime'] = articleUrlDic['publishTime']
            articleModel['thumbnail'] = articleUrlDic['imgUrl']
            articleModel['source'] = articleUrlDic['source']
            articleModel['publishTime'] = articleUrlDic['publishTime']

            articleModel['content'] = contentHtml
            articleModel['imgs'] = imgs
            articleModel['forward_cnt'] = readNum
            articleModel['praise_cnt'] = likeNum
            articleModel['processTime'] = TimeUtil().currentTime()
            articleModel['identifiers'] = articleUrlDic['identifiers'] #公众号文章名字有时候是一样的

            #直接保存入库了

            self.dataCenter.resultIn(articleModel)
            print 'reslut in'
        #return resultList
        #print json.dumps(articleModel)

    def getImgName(self, urlS):
        temList = urlS.split('fmt=')

        tempName = self.get_md5_value(urlS)
        if len(temList) == 2:
            tempName = tempName + '.'+ temList[1]
        # else:
        #     tempName = tempName + '.jpg'

        return tempName


    def get_md5_value(self, src):
        myMd5 = hashlib.md5()
        if isinstance(src,list):
            for item in src:
                myMd5.update(item)
        else:
            myMd5.update(src)
        myMd5_Digest = myMd5.hexdigest()
        return myMd5_Digest

    def fetchOfficialAccountElement(self,_driver = None,
                                    officialAccountName = None,weChatName = None):
        #返回 officialAccountNameUrl
        if _driver is None :
            print '提取公众号url时, _drvier can not be None'
            return  None

        #这里暂时采用全局变量
        def currnetArtil(contain):
            if contain is None:
                return  None
            sourseList = self.element_actions.wait_elements_css(elementObj=contain,
                                                                val='div#main ul.news-list2 > li',
                                                                timeOut=10)
            if sourseList is None:

                return  None

            for sourse in  sourseList:
                tempOfficialAccountsE = self.element_actions.wait_elements_css(elementObj=sourse,val='div.txt-box p.tit em')

                if tempOfficialAccountsE is None or len(tempOfficialAccountsE)<=0:
                    continue

                tempNameStr = ''
                for item in  tempOfficialAccountsE:
                    tempNameStr = tempNameStr + item.text

                if tempNameStr != officialAccountName or len(tempNameStr)<=0:
                    continue

                if weChatName is None:

                    tempUrlE = self.element_actions.wait_element_css(elementObj=sourse, val='div.txt-box p.tit a')

                    if tempUrlE is None:
                        return None

                    tempUrl = self.element_actions.get_attribute(elementObj=tempUrlE, attributeName='href')

                    return tempUrl
                else:
                    #比对微信号
                    tempWeChatE = self.element_actions.wait_element_css(elementObj=sourse,val='div.txt-box p.info label')

                    if tempWeChatE is None:
                        continue
                    tempWeChatName = tempWeChatE.text

                    if weChatName !=tempWeChatName:
                        continue

                    tempUrlE = self.element_actions.wait_element_css(elementObj=sourse,val='div.txt-box p.tit a')

                    if tempUrlE is None:
                        return None

                    tempUrl = self.element_actions.get_attribute(elementObj=tempUrlE,attributeName='href')

                    return tempUrl


            return  None
        def currentPageNumFun(contain):

            # 当前页元素找不到,返回 0

            num = None
            span = self.element_actions.wait_element_css(val='div#pagebar_container span',
                                                         elementObj=contain, timeOut=10)

            if span is not None:
                return span.text

            return num

        def next_btn(containe):

            nxBtn = self.element_actions.wait_element_css(val='div#pagebar_container a#sogou_next',
                                                                elementObj=containe, timeOut=10)
            return nxBtn

        # 在进入下一页的翻页之前,会先处理一次当前页的数据.
        # container = article_container(self.currentModelNum)
        #
        # if container is None:
        #     return
        # else:
        #     element.execute_script('window.stop()')

        url = currnetArtil(_driver)
        #print url
        if url is not None:
            #print '返回url'
            return url
        nextBtn = next_btn(_driver)
        currentPageNum = currentPageNumFun(_driver)
        #totoalNum = totoal_num(_driver)

        if currentPageNum is None :
            return None
        loopNum = 0
        _driver.set_page_load_timeout(time_to_wait=2)
        while  nextBtn is not None:
            # print  '开始翻页循环'
            tryTimes = 0
            maxTimes = 5
            # self.element_actions.show_elements(_driver= element, _element=nextBtn)
            # a = time.time()
            if not self.element_actions.element_click_webloadtimeIsSeted(elementObj=nextBtn,
                                                                         web_wait_time_isSetted=True):
                break
            _driver.execute_script('window.stop()')

            time.sleep(2)

            if loopNum >= 4:
                print '无法进入下一页,当前分类分页获取结束:'
                print _driver.current_url
                break

            while tryTimes < maxTimes:
                tryTimes += 1
                container = _driver
                lastNum = currentPageNum
                currentPageNum = currentPageNumFun(container)
                nextBtn = next_btn(container)

                if currentPageNum is None or lastNum == currentPageNum:
                    loopNum += 1
                    print 'currentPageNum:' + str(currentPageNum)
                    print 'trytimes' + str(tryTimes)
                    continue
                else:
                    loopNum = 0
                    # print  '解析当前页'+str(currentPageNum)
                    currnetArtil(container)
                    break

            return None
        return None

    def fecthFirstAccount(self):

        # 获取公众号列表的第一个
        firstAccount = self.element_actions.wait_element_css(elementObj=self.driver, val='li#sogou_vr_11002301_box_0')
        if firstAccount is None:
            print  '公众号列表获取失败'
            return None

        accountNameBtn = self.element_actions.wait_element_css(elementObj=firstAccount, val='p.tit a')

        accountUlr = self.element_actions.get_attribute(elementObj=accountNameBtn, attributeName='href')

        return accountUlr

    def closeDrive(self):
        self.driver.quit()


if __name__ == '__main__':
    # g = GZH_Spider()
    # s = ['dfeuwrioeruewruweruewruopuoroeur','dsfdfd']
    #
    # print  g.get_md5_value(s)
    # drr = webdriver.PhantomJS(executable_path='/Users/lianzhu/Documents/python/driver/phantomjs')
    # drr.get('http://weixin.sogou.com/')
    # print drr.get_cookies()

    g = GZH_Spider()
    ar = [{'url':'http://mp.weixin.qq.com/s?timestamp=1497499080&src=3&ver=1&signature=*xjNy4kMpqoKT6*S5wGK1JiCSRandKFLXUdLg0NbgWuX5iUcjbF2EHaVKBxX9KFE*6P0h6SbC2H3-5uhofM6gbEjT7rTWxUcVvaG8qi0BLQsYLz0a1FloUjJ4CmAq77ma33z89L1hQW8ul27YehtzFSDtCHNcUOrtHIawj0caPI='}]
    g.parseArticle(ar)
